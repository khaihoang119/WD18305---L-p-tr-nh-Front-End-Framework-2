import React, { useState } from "react";

const Header = () => {
  const [count, setCount] = useState(0);
  return (
    <h1 className="text-warning" onClick={setCount?.bind(this, count + 1)}>
      {count}
    </h1>
  );
};

export default Header;
