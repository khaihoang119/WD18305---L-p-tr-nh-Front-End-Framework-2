import React, { useEffect } from "react";
import { useForm } from "react-hook-form";
import { useDispatch } from "react-redux";
import { Student } from "../../redux/actions";
import { useNavigate } from "react-router-dom";

const StudentFrom = () => {
  const { register, handleSubmit } = useForm();
  const dispatch = useDispatch();
  const naviagte = useNavigate();

  const submit = (value) => {
    dispatch(Student.addStudent({ ...value }));
    naviagte("/student-list");
  };

  return (
    <div className="container p-3">
      <h1 className="text-primary mb-3 text-center">Thêm sinh viên</h1>

      <div className="mb-3">
        <label htmlFor="" className="form-label">
          Code
        </label>
        <input
          type="text"
          className="form-control"
          placeholder="Code"
          {...register("code")}
        />
      </div>

      <div className="mb-3">
        <label htmlFor="" className="form-label">
          Name
        </label>
        <input
          type="text"
          className="form-control"
          placeholder="Nam"
          {...register("name")}
        />
      </div>

      <div className="mb-3">
        <label htmlFor="" className="form-label">
          Address
        </label>
        <input
          type="text"
          className="form-control"
          placeholder="Address"
          {...register("address")}
        />
      </div>

      <button
        type="button"
        className="btn btn-primary"
        onClick={handleSubmit(submit)}
      >
        Thêm
      </button>
    </div>
  );
};

export default StudentFrom;
