import React, { useState } from "react";
// import Header from "../../components/Header";

const Dashboard = () => {
  const [title, setTitle] = useState("Dashboard");
  return (
    <div>
      {/* header */}
      {/* <Header /> */}
      <h1
        className="text-success"
        onClick={setTitle?.bind(this, title == "" ? "Products" : "Dashboard")}
      >
        Dashboard
      </h1>
      {/* Footer */}
    </div>
  );
};

export default Dashboard;

// http://localhost:3000/admin/
// http://localhost:3000/admin/products
// http://localhost:3000/admin/product-form
