import React, { useEffect } from "react";
import { useSearchParams, useParams } from "react-router-dom";

const ProductDetail = () => {
  //Query params
  const [searchParams, setSearchParams] = useSearchParams();
  //Path params
  const params = useParams();

  useEffect(() => {
    console.log("query params === ", searchParams.get("id"));
    console.log("path params === ", params);
  }, []);

  return (
    <div>
      <h1>Product Detail</h1>
    </div>
  );
};

export default ProductDetail;

// id = 123
// http://localhost:3000/admin/product-detail?id=123 => Query params (Search params)
// http://localhost:3000/admin/product-detail/123 => Path params
