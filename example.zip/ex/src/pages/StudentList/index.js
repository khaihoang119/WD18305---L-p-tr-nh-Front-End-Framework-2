import React, { useEffect } from "react";
import { useSelector } from "react-redux";
import { Link, useNavigate } from "react-router-dom";

const StudentList = () => {
  const students = useSelector((state) => state?.student?.students);
  const navigate = useNavigate();

  useEffect(() => {
    console.log("students === ", students);
    // window.location.href = "";
  }, []);

  return (
    <div className="container p-3">
      <h1 className="text-primary mb-3 text-center">Danh sách sinh viên</h1>
      <Link type="button" className="btn btn-primary mb-3" to="/student-form">
        Thêm sinh viên
      </Link>

      <div className="table-responsive">
        <table className="table table-primary">
          <thead>
            <tr>
              <th scope="col">No.</th>
              <th scope="col">Code</th>
              <th scope="col">Name</th>
              <th scope="col">Address</th>
            </tr>
          </thead>
          <tbody>
            {students?.map((value, index) => {
              return (
                <tr className="" key={String(index)}>
                  <td scope="row">{index + 1}</td>
                  <td>{value?.code}</td>
                  <td>{value?.name}</td>
                  <td>{value?.address}</td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default StudentList;
