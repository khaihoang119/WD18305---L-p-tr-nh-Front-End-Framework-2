export default {
  MINUS: "MINUS",
  PLUS: "PLUS",
  CLEAN: "CLEAN",
  UPDATE_COUNT: "UPDATE_COUNT",
};
