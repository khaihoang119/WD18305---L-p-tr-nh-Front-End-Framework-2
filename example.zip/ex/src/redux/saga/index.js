import { all } from "redux-saga/effects";
import countWatch from "./Count";
import authWatch from "./Auth";
import studentWatch from "./Student";

function* middleware() {
  yield all([countWatch(), authWatch(), studentWatch()]);
}

export default middleware;
