import { all, select, put, takeLatest } from "redux-saga/effects";
import { Auth } from "../../types";
import { getProfile } from "../../../services/Auth";

function* authWatch() {
  yield all([takeLatest(Auth.USER_INFO, getUserInfo)]);
}

function* getUserInfo() {
  //TODO

  const res = yield getProfile();

  yield put({
    type: Auth.AUTH_UPDATE,
    payload: {
      profile: res,
    },
  });
}

export default authWatch;
