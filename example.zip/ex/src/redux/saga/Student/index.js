import { all, put, takeLatest, select } from "redux-saga/effects";
import { Student } from "../../types";

export default function* studentWatch() {
  yield all([takeLatest(Student.ADD_STUDENT, addStudent)]);
}

// payload = {code: "abc", name: "abc", address: "abc"}

function* addStudent({ type, payload }) {
  //Lấy danh sách student trong Store
  //Thêm thông tin sinh viên vừa nhận được từ payload
  //vào danh sách vừa lấy ra được
  //Đẩy dữ liệu qua reducer

  const students = yield select((state) => state.student.students);
  // console.log("middleware log === ", students);

  yield put({
    type: Student.STUDENT_LIST_UPDATE,
    payload: {
      students: [
        ...students,
        {
          code: payload?.code,
          name: payload?.name,
          address: payload?.address,
        },
      ],
    },
  });
}
