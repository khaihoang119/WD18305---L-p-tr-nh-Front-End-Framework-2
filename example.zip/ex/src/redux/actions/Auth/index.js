import { Auth } from "../../types";

const getProfile = () => {
  return {
    type: Auth.USER_INFO,
  };
};

export { getProfile };
