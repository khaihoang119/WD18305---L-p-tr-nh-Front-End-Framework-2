import * as Count from "./Count";
import * as Auth from "./Auth";
import * as Student from "./Student";

export { Count, Auth, Student };
