import React from "react";
import "./App.css";
import "bootstrap/dist/css/bootstrap.min.css";
import {
  RouterProvider,
  Route,
  createBrowserRouter,
  createRoutesFromElements,
} from "react-router-dom";
import { CookiesProvider } from "react-cookie";
import { Provider } from "react-redux";
import store from "./redux";
import Login from "./pages/Login";
import Register from "./pages/Register";
import Profile from "./pages/Profile";
import StudentList from "./pages/StudentList";
import StudentFrom from "./pages/StudentForm";
import Dashboard from "./pages/Dashboard";
import Products from "./pages/Products";
import AdminPage from "./pages/AdminPage";
import ProductDetail from "./pages/ProductDetail";

function App() {
  const router = createBrowserRouter(
    createRoutesFromElements(
      <Route>
        <Route path="/" element={<div></div>} />
        <Route path="login" element={<Login />} />
        <Route path="register" element={<Register />} />
        <Route path="profile" element={<Profile />} />
        <Route path="student-list" element={<StudentList />} />
        <Route path="student-form" element={<StudentFrom />} />

        <Route path="/user">
          <Route path="" />
          <Route path="order" />
          <Route path="cart" />
        </Route>

        <Route path="/admin" element={<AdminPage />}>
          <Route path="" element={<Dashboard />} />
          <Route path="products" element={<Products />} />
          {/* Path params */}
          {/* http://localhost:3000/admin/product-detail/123 => pass */}
          {/* <Route path="product-detail/:id" element={<ProductDetail />} /> */}
          {/* http://localhost:3000/admin/product-detail => pass */}
          {/* http://localhost:3000/admin/product-detail?id=123 => pass */}
          {/* <Route path="product-detail" element={<ProductDetail />} /> */}
          {/* Query params */}

          <Route path="product-detail" element={<ProductDetail />}>
            <Route path="" />
            <Route path=":id" />
          </Route>
        </Route>
      </Route>
    )
  );

  return (
    <>
      <Provider store={store}>
        <CookiesProvider defaultSetOptions={"/"}>
          <RouterProvider router={router} />
        </CookiesProvider>
      </Provider>
    </>
  );
}

export default App;
