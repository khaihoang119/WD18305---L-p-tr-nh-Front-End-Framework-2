import { all } from "redux-saga/effects";

function* middleware() {
  yield all([]);
}

export default middleware;
