export default {
  MINUS: "MINUS",
  PLUS: "PLUS",
  CLEAN: "CLEAN",
};
